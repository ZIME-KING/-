#ifndef   __UART__H
#define   __UART__H
void I2CReceive(void);
void start_tx(u8 len);
void Transmit(void);
#endif